-----------------------------------------------------------------------------
OpenSSL v1.0.0a, Precompiled Binaries for Win64
-----------------------------------------------------------------------------

Released Date:  June 17, 2010

Created by:     Arvid Winkelsdorf (digivendo GmbH, www.digivendo.com)
                for The Indy Project (www.indyproject.org)

Dependencies:   Requires Indy SVN (10.5.5+)

THIS SOFTWARE IS PROVIDED BY THE INDY PROJECT 'AS IS'. Please see the
OpenSSL license terms in the file "OpenSSL License.txt".

PLEASE CHECK IF YOU NEED TO COMPLY WITH EXPORT RESTRICTIONS FOR CRYPTOGRAPHIC
SOFTWARE AND / OR PATENTS (WHERE APPLICABLE).

Build Informations
------------------

Built with:     Platform SDK Windows Server 2003 (Release Mode)
                Strawberry Perl v5.12.0.1 built for MSWin32-x86-multi-thread

Shell:          Microsoft Platform SDK Set Win Svr 2003 x64 Build Env (Retail)

Build commands: perl configure VC-WIN64A no-asm
                ms\do_win64a
                adjusted ms\version32.rc (Indy Information inserted)
                nmake -f ms\ntdll.mak
                editbin.exe /rebase:base=0�11000000 libeay32.dll
                editbin.exe /rebase:base=0�12000000 ssleay32.dll                

Test command:   nmake -f ms\ntdll.mak test

Comment:
  Libraries are compiled with dependencies to the MS VC++ 2008 runtime. You
  will need to ship the MS VC++ 2008 runtime together with your application!

----------------------------------------------------------------------------- 