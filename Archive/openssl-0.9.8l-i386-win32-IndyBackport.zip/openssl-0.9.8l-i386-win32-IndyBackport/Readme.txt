-----------------------------------------------------------------------------
OpenSSL v0.9.8l, Precompiled Binaries for Win32, BACKPORT Indy 9/10
-----------------------------------------------------------------------------

Released Date:  November 9, 2009

Created by:     Arvid Winkelsdorf (digivendo GmbH, www.digivendo.com)
                for The Indy Project (www.indyproject.org)

Dependencies:   Requires Indy v9 / v10

THIS SOFTWARE IS PROVIDED BY THE INDY PROJECT 'AS IS'. Please see the
OpenSSL license terms in OpenSSL-License.txt.

Notes
-----

*** WE DO NOT SUGGEST USING OLD INDY VERSIONS LIKE v9 OR EARLY v10 ***

- for use with old Indy 9 / 10 installations

- rename IdSSLOpenSSLHeaders9.pas or IdSSLOpenSSLHeaders10.pas to
  IdSSLOpenSSLHeaders.pas depending on the version you installed together with
  Delphi

- copy new IdSSLOpenSSLHeaders.pas to your compiler's and/or project's search path

  or

  rename IdSSLOpenSSLHeader.pas in your Indy\lib\Protocols directory to
  something like IdSSLOpenSSLHeader.original.pas and copy new 
  IdSSLOpenSSLHeaders.pas to Indy\lib\Protocols directory

- Rebuild all Packages and Projects

- ship a copy of the DLLs with every application

Build Informations
------------------

Built with:     MinGW-5.1.4 / gcc 3.4.5 (mingw-vista special r3)
                Strawberry Perl v5.10.1.0 built for MSWin32-x86-multi-thread
Commands:       perl configure mingw
                ms\mingw32				 
Test commands:  cd out
                ..\ms\test
Renaming:       \libssl32.dll to \ssleay32.dll

Comment:
  Win32 DLLs built using Mingw32 in order to provide best support for older 
  OS (e.g. Win9x/2k) by linking against msvcrt.dll. Building libraries with 
  compilers like MS VC++ 2005/2008 would require installation of MS VC 
  Runtime Libaries on some target systems.

----------------------------------------------------------------------------- 