-----------------------------------------------------------------------------
OpenSSL v0.9.8l, Precompiled Binaries for Win64
-----------------------------------------------------------------------------

Released Date:  November 9, 2009

Created by:     Arvid Winkelsdorf (digivendo GmbH, www.digivendo.com)
                for The Indy Project (www.indyproject.org)

Dependencies:   Requires Indy v10.2.5/10.5.5 or higher (SVN)
                (i.e. Indy preinstalled with Delphi 2009/2010)

THIS SOFTWARE IS PROVIDED BY THE INDY PROJECT 'AS IS'. Please see the
OpenSSL license terms in OpenSSL-License.txt.

Build Informations
------------------

Built with:     Platform SDK Windows Server 2003 (Release Mode)
                Strawberry Perl v5.10.1.0 built for MSWin32-x86-multi-thread
Shell:          Microsoft Platform SDK Set Win Svr 2003 x64 Build Env (Retail)			 
Commands:       perl configure VC-WIN64A
                ms\do_win64a
                nmake -f ms\ntdll.mak
Tested with:    cd out32dll
                ..\ms\test

----------------------------------------------------------------------------- 