Indy OpenSSL 0.9.8h IntraWeb Edition
Sep, 10th 2008
Copyright (c) 2008 digivendo GmbH, Arvid Winkelsdorf
www.digivendo.de, info[at]digivendo[dot]de
---

- for use with Indy versions that are preinstalled with Delphi
  (Indy 9 / Indy 10) up to D2007 (not needed with D2009)

- rename IdSSLOpenSSLHeaders9.pas or IdSSLOpenSSLHeaders10.pas to
  IdSSLOpenSSLHeaders.pas depending on the version you installed together with
  Delphi

- copy new IdSSLOpenSSLHeaders.pas to your compiler's and/or project's search path

  or

  rename IdSSLOpenSSLHeader.pas in your Indy\lib\Protocols directory to
  something like IdSSLOpenSSLHeader.original.pas and copy new 
  IdSSLOpenSSLHeaders.pas to Indy\lib\Protocols directory

- Rebuild any Packages or Projects. If new headerfile is correctly used
  you will see a compiler hint showing "Using Indy OpenSSL 0.9.8h"

- ship a copy of the dlls from "openssl-0.9.8h - DLLs - Indy" with every 
  application needing Indy OpenSSL support

Note:
with the latest Indy Trunk (10.2.3) or SVN the Indy OpenSSL DLLs are no longer needed.
If you are using the latest Trunk or SVN source you can use the original build dlls
from "openssl-0.9.8h - DLLs - Default - Win32". The changed headerfiles are not 
needed in this case.