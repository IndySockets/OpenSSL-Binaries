/************************************************************************/
/* INDY EXPORTS - GREGOR IBIC, INTELICOM d.o.o. BEGIN                   */
/************************************************************************/

#include <openssl/ssl.h>
#include "indy_ssl.h"

/*int SSL_set_app_data_indy(SSL *s, void *arg){
  return (SSL_set_ex_data(s, 0, (char *)arg));
};

void *SSL_get_app_data_indy(SSL *s){
  return ((void *)SSL_get_ex_data(s, 0));
};
*/
void SSL_CTX_set_info_callback_indy(SSL_CTX *ctx, void (*cb)()){
  SSL_CTX_set_info_callback(ctx, cb);
};

void *X509_STORE_CTX_get_app_data_indy(X509_STORE_CTX *ctx){
  return (X509_STORE_CTX_get_app_data(ctx));
};

ASN1_UTCTIME *X509_get_notBefore_indy(X509 *x509){
  return (X509_get_notBefore(x509));
};

ASN1_UTCTIME *X509_get_notAfter_indy(X509 *x509){
  return (X509_get_notAfter(x509));
};

/*
int UCTTimeDecode_indy( ASN1_UTCTIME *UCTtime,
			unsigned short *year, unsigned short *month,
			unsigned short *day, unsigned short *hour,
			unsigned short *min, unsigned short *sec,
			int *tz_hour, int *tz_min ){
  int i=0;
  int length=0;
  int tz_dir=0;
  static char *time_str=NULL;
  static char xx[1024];

  time_str=(char *)UCTtime->data;
  length=UCTtime->length;
  
  for (i=0; i<12; i++) // Check if first 12 chars are numbers
    if ((time_str[i]>'9')||(time_str[i]<'0')) return(1);
  // Convert time from string to number
  *year =10*(time_str[ 0]-'0')+(time_str[ 1]-'0')+1900;
  *month=10*(time_str[ 2]-'0')+(time_str[ 3]-'0');
  *day  =10*(time_str[ 4]-'0')+(time_str[ 5]-'0');
  *hour =10*(time_str[ 6]-'0')+(time_str[ 7]-'0');
  *min  =10*(time_str[ 8]-'0')+(time_str[ 9]-'0');
  *sec  =10*(time_str[10]-'0')+(time_str[11]-'0');
  // Fix year. This function is Y2k but isn't compatible with Y2k5 :-(
  if (*year<1950) *year+=100;
  // Check TZ
  *tz_hour = *tz_min = 0;
  if ((time_str[12]=='-')||(time_str[12]=='+')) {
    if (time_str[12]=='-') {
       tz_dir=-1;
    } else {
       tz_dir=1;
    };
    for (i=13; i<18; i++) { // Check if numbers are numbers
      if (i==15) continue;
      if ((time_str[i]>'9')||(time_str[i]<'0')) return(1);
    };
    *tz_hour = (10*(time_str[13])+(time_str[14]))*tz_dir;
    *tz_min  = (10*(time_str[16])+(time_str[17]))*tz_dir;
  };
  
  return (1);
};
*/
int SSL_SESSION_get_id_indy(SSL_SESSION *s, char **id, int *length){
  *id=s->session_id;
  *length=s->session_id_length;
  return(*length);
};

int SSL_SESSION_get_id_ctx_indy(SSL_SESSION *s, char **id, int *length){
  *id=s->sid_ctx;
  *length=s->sid_ctx_length;
  return(*length);
};

int SSL_CTX_get_version_indy(SSL_CTX *ctx){
  return(ctx->method->version);
};

long SSL_CTX_set_options_indy(SSL_CTX *ctx, long op){
  return (SSL_CTX_set_options(ctx, op));
};



/************************************************************************/
/* INDY EXPORTS - GREGOR IBIC, INTELICOM d.o.o. END                     */
/************************************************************************/

