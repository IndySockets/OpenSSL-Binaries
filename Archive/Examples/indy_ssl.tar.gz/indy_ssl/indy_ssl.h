/************************************************************************/
/* INDY EXPORTS - GREGOR IBIC, INTELICOM d.o.o. BEGIN                   */
/************************************************************************/
/* #ifdef INDY */

// int SSL_set_app_data_indy(SSL *s, void *arg);
// void *SSL_get_app_data_indy(SSL *s);
void SSL_CTX_set_info_callback_indy(SSL_CTX *ctx, void (*cb)());
void *X509_STORE_CTX_get_app_data_indy(X509_STORE_CTX *ctx);
ASN1_UTCTIME *X509_get_notBefore_indy(X509 *x509);
ASN1_UTCTIME *X509_get_notAfter_indy(X509 *x509);
// int UCTTimeDecode_indy( ASN1_UTCTIME *UCTtime,
//			unsigned short *year, unsigned short *month,
//			unsigned short *day, unsigned short *hour,
//			unsigned short *min, unsigned short *sec,
//			int *tz_hour, int *tz_min );
int SSL_SESSION_get_id_indy(SSL_SESSION *s, char **id, int *length);
int SSL_SESSION_get_id_ctx_indy(SSL_SESSION *s, char **id, int *length);
int SSL_CTX_get_version_indy(SSL_CTX *ctx);
long SSL_CTX_set_options_indy(SSL_CTX *ctx, long op);


/* #endif */
/************************************************************************/
/* INDY EXPORTS - GREGOR IBIC, INTELICOM d.o.o. END                     */
/************************************************************************/
